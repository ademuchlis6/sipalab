#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  `username` varchar(100) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ci_sessions_timestamp` (`timestamp`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`, `username`) VALUES ('nsskes6brlvtbgugvv8rsiqh1lsg4mvq', '::1', '1606744509', '__ci_last_regenerate|i:1606744012;identity|s:13:\"opr@gmail.com\";username|s:10:\"oprsipalab\";email|s:13:\"opr@gmail.com\";user_id|s:1:\"2\";old_last_login|s:10:\"1606743081\";sesusername|s:10:\"oprsipalab\";seslokasi|s:1:\"2\";acdel|b:0;', 'oprsipalab');


#
# TABLE STRUCTURE FOR: groups
#

DROP TABLE IF EXISTS `groups`;

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('1', 'admin', 'Administrator');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('2', 'opr', 'Operator');


#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS `login_attempts`;

CREATE TABLE `login_attempts` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO `migrations` (`version`) VALUES ('1');


#
# TABLE STRUCTURE FOR: tbl_catatan
#

DROP TABLE IF EXISTS `tbl_catatan`;

CREATE TABLE `tbl_catatan` (
  `id_catatan` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_ambil_sample` date DEFAULT NULL,
  `transport` varchar(100) DEFAULT NULL,
  `pengawetan` varchar(100) DEFAULT NULL,
  `paramlap` varchar(100) DEFAULT NULL,
  `catatan_kwi` varchar(255) DEFAULT NULL,
  `bml` varchar(255) DEFAULT NULL,
  `tgl_kwi` date DEFAULT NULL,
  `nomor_order` int(11) DEFAULT NULL,
  `tahun_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_catatan`),
  KEY `idx_catatan` (`nomor_order`,`tahun_order`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_catatan` (`id_catatan`, `tgl_ambil_sample`, `transport`, `pengawetan`, `paramlap`, `catatan_kwi`, `bml`, `tgl_kwi`, `nomor_order`, `tahun_order`) VALUES ('39', '2020-11-30', 'MOBIL', 'ES BATU', 'PH, TSS', 'Catatan PT. NUTRISANA', 'Permen LH NO.5 Th.2014', '2020-12-04', '1', '2020');


#
# TABLE STRUCTURE FOR: tbl_config
#

DROP TABLE IF EXISTS `tbl_config`;

CREATE TABLE `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_config` varchar(255) DEFAULT NULL,
  `value_config` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_config` (`id`, `nama_config`, `value_config`) VALUES ('1', 'TGL ISO', '04 Desember 2019');
INSERT INTO `tbl_config` (`id`, `nama_config`, `value_config`) VALUES ('2', 'FORM ISO', 'FORM 7.5-02');
INSERT INTO `tbl_config` (`id`, `nama_config`, `value_config`) VALUES ('3', 'TERBITAN', 'Terbitan/Rev: 3/1');
INSERT INTO `tbl_config` (`id`, `nama_config`, `value_config`) VALUES ('4', 'BML', 'Permen LH NO. 5 Th. 2014');


#
# TABLE STRUCTURE FOR: tbl_order
#

DROP TABLE IF EXISTS `tbl_order`;

CREATE TABLE `tbl_order` (
  `id_order` int(11) NOT NULL AUTO_INCREMENT,
  `nomor_order` int(11) DEFAULT NULL,
  `tahun_order` int(11) DEFAULT NULL,
  `nama_pemohon` varchar(100) DEFAULT NULL,
  `nama_perusahaan` varchar(100) DEFAULT NULL,
  `alamat_perusahaan` varchar(255) DEFAULT NULL,
  `telp_perusahaan` varchar(100) DEFAULT NULL,
  `fax_perusahaan` varchar(100) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_order`),
  KEY `idx_order` (`nomor_order`,`tahun_order`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_order` (`id_order`, `nomor_order`, `tahun_order`, `nama_pemohon`, `nama_perusahaan`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`) VALUES ('1', '2', '2019', 'ADE MUCHLIS', 'PT. COBA COBA', 'CIBINONG, BOGOR', '0811111', '021111', '2020-10-22 21:59:49');
INSERT INTO `tbl_order` (`id_order`, `nomor_order`, `tahun_order`, `nama_pemohon`, `nama_perusahaan`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`) VALUES ('37', '1', '2020', 'P. HIDAYAT', 'PT. TATA NUTRISNA', 'JL. LANBAU KM.6 DS. LEUWINUTUNG KEC. CITEUREUP KAB. BOGOR', '082299222900', '', '2020-11-30 20:50:35');


#
# TABLE STRUCTURE FOR: tbl_param
#

DROP TABLE IF EXISTS `tbl_param`;

CREATE TABLE `tbl_param` (
  `id_param` int(11) NOT NULL AUTO_INCREMENT,
  `nama_param` varchar(255) NOT NULL,
  `tipe_param` varchar(255) NOT NULL,
  `harga` int(255) NOT NULL,
  PRIMARY KEY (`id_param`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('1', 'Suhu', 'Air dan Air Limbah', '9500');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('2', 'TDS portable', 'Air dan Air Limbah', '22500');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('3', 'TDS Gravimetri', 'Air dan Air Limbah', '34900');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('4', 'TSS', 'Air dan Air Limbah', '34000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('5', 'Residu Total Gravimetri', 'Air dan Air Limbah', '30400');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('6', 'Salinitas', 'Air dan Air Limbah', '14200');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('7', 'DHL', 'Air dan Air Limbah', '15900');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('8', 'Kekeruhan', 'Air dan Air Limbah', '15336');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('9', 'Warna', 'Air dan Air Limbah', '15700');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('10', 'pH', 'Air dan Air Limbah', '33850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('11', 'Sulfide', 'Air dan Air Limbah', '17350');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('12', 'Klorida (Cl) free', 'Air dan Air Limbah', '28300');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('13', 'Klorin (Cl2) total', 'Air dan Air Limbah', '28300');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('14', 'NH3-N', 'Air dan Air Limbah', '24400');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('15', 'NO3-N (HACH)', 'Air dan Air Limbah', '24650');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('16', 'NO3-N  (SNI)', 'Air dan Air Limbah', '23800');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('17', 'NO2-N  (HACH)', 'Air dan Air Limbah', '21250');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('18', 'NO2-N (SNI)', 'Air dan Air Limbah', '24350');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('19', 'Ortho Posphat', 'Air dan Air Limbah', '23050');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('20', 'Total Fosfat (P-total)', 'Air dan Air Limbah', '26800');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('21', 'DO', 'Air dan Air Limbah', '20100');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('22', 'DO Titrimetri', 'Air dan Air Limbah', '32800');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('23', 'Barium (HACH)', 'Air dan Air Limbah', '38000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('24', 'Barium secara AAS', 'Air dan Air Limbah', '33100');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('25', 'Crom Heksa (HACH)', 'Air dan Air Limbah', '33500');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('26', 'Crom Heksa (SNI)', 'Air dan Air Limbah', '27250');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('27', 'Cyanide(HACH)', 'Air dan Air Limbah', '52300');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('28', 'Crom Total secara AAS', 'Air dan Air Limbah', '30900');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('29', 'Sulfat (HACH)', 'Air dan Air Limbah', '24150');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('30', 'Sulfat (SNI)', 'Air dan Air Limbah', '24250');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('31', 'Mn ', 'Air dan Air Limbah', '31850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('32', 'Fe', 'Air dan Air Limbah', '32000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('33', 'Zn ', 'Air dan Air Limbah', '31850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('34', 'Cu ', 'Air dan Air Limbah', '31850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('35', 'BOD', 'Air dan Air Limbah', '62000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('36', 'COD', 'Air dan Air Limbah', '63850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('37', 'Cd ', 'Air dan Air Limbah', '31850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('38', 'Pb', 'Air dan Air Limbah', '31850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('39', 'Hg ', 'Air dan Air Limbah', '79950');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('40', 'Fluoride (HACH)', 'Air dan Air Limbah', '29250');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('41', 'Phenol (HACH)', 'Air dan Air Limbah', '53650');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('42', 'Minyak dan Lemak', 'Air dan Air Limbah', '42650');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('43', 'Detergen (HACH)', 'Air dan Air Limbah', '52050');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('44', 'Arsen ', 'Air dan Air Limbah', '66300');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('45', 'Coli dan Total Coliform', 'Air dan Air Limbah', '181050');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('46', 'Alkalinitas', 'Air dan Air Limbah', '14500');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('47', 'Aciditas', 'Air dan Air Limbah', '14500');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('48', 'Kesadahan Ca', 'Air dan Air Limbah', '20000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('49', 'Kesadahan Mg', 'Air dan Air Limbah', '20000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('50', 'Kesadahan Total', 'Air dan Air Limbah', '20000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('51', 'Nilai Permanganat ', 'Air dan Air Limbah', '21500');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('52', 'Nitrogen Organik', 'Air dan Air Limbah', '38800');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('53', 'Ortho Posphat', 'Air dan Air Limbah', '23050');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('54', 'Total Fosfat (P-total)', 'Air dan Air Limbah', '26800');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('55', 'Selenium ', 'Air dan Air Limbah', '66350');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('56', 'Suhu Udara', 'Udara Ambient', '24100');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('57', 'Kelembaban udara dan CO2', 'Udara Ambient', '37650');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('58', 'Partikel debu (TSP) 1 jam', 'Udara Ambient', '102100');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('59', 'Sulfurdioksida ( SO2 )', 'Udara Ambient', '103800');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('60', 'Nitrogen Oksida ( NO2 )', 'Udara Ambient', '62000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('61', 'Dihidrogen Sulfur ( H2S )', 'Udara Ambient', '91050');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('62', 'Amonia (NH3)', 'Udara Ambient', '102600');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('63', 'Ozon ( O3 )', 'Udara Ambient', '101350');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('64', 'Kebisingan', 'Udara Ambient', '37650');


#
# TABLE STRUCTURE FOR: tbl_sample
#

DROP TABLE IF EXISTS `tbl_sample`;

CREATE TABLE `tbl_sample` (
  `id_sample` int(11) NOT NULL AUTO_INCREMENT,
  `nomor_sample` int(11) DEFAULT NULL,
  `tahun_sample` int(11) DEFAULT NULL,
  `kode_uji` varchar(100) DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `jumlah` varchar(100) DEFAULT NULL,
  `nomor_order` int(11) DEFAULT NULL,
  `tahun_order` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_sample`),
  KEY `idx_sample` (`nomor_order`,`tahun_order`,`nomor_sample`,`tahun_sample`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('1', '1', '2019', 'KODE UJI 1', 'JERIGEN', '1000', '1', '2019', '2020-10-22 22:00:29');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('48', '1', '2020', 'INLET IPAL', 'BOTOL AMDK', '1500', '1', '2020', '2020-11-30 20:51:17');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('49', '2', '2020', 'OUTLET IPAL', 'BOTOL AMDK', '1500', '1', '2020', '2020-11-30 20:52:02');


#
# TABLE STRUCTURE FOR: tbl_sample_param
#

DROP TABLE IF EXISTS `tbl_sample_param`;

CREATE TABLE `tbl_sample_param` (
  `id_sample_param` int(11) NOT NULL AUTO_INCREMENT,
  `id_parameter` int(11) NOT NULL,
  `nomor_sample` int(11) NOT NULL,
  `tahun_sample` int(11) NOT NULL,
  `nomor_order` int(11) NOT NULL,
  `tahun_order` int(11) NOT NULL,
  PRIMARY KEY (`id_sample_param`),
  KEY `idx_sample_param` (`nomor_order`,`tahun_order`,`nomor_sample`,`tahun_sample`)
) ENGINE=InnoDB AUTO_INCREMENT=564 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('1', '1', '1', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('2', '2', '1', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('3', '4', '1', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('557', '4', '1', '2020', '1', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('558', '35', '1', '2020', '1', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('559', '36', '1', '2020', '1', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('560', '4', '2', '2020', '1', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('561', '7', '2', '2020', '1', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('562', '10', '2', '2020', '1', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('563', '36', '2', '2020', '1', '2020');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(80) NOT NULL,
  `salt` varchar(40) NOT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `wilayah` varchar(20) DEFAULT NULL,
  `id_wilayah` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1004 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `wilayah`, `id_wilayah`) VALUES ('1', '::1', 'adminsipalab', '$2y$08$geZEwpqBeNSIBbuYNFoHLuflONM/qpOxhcwD1jXqfNNmV7t4KmxIG', '', 'ver@gmail.com', NULL, NULL, NULL, NULL, '1584069727', '1606742160', '1', 'verificator', 'verificator', 'ADMIN', '0', 'ADMIN', NULL);
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `wilayah`, `id_wilayah`) VALUES ('2', '::1', 'oprsipalab', '$2y$08$geZEwpqBeNSIBbuYNFoHLuflONM/qpOxhcwD1jXqfNNmV7t4KmxIG', '', 'opr@gmail.com', NULL, NULL, NULL, NULL, '1584069727', '1606744101', '1', 'verificator', 'verificator', 'OPERATOR', '0', 'OPERATOR', NULL);


#
# TABLE STRUCTURE FOR: users_groups
#

DROP TABLE IF EXISTS `users_groups`;

CREATE TABLE `users_groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('1', '1', '1');
INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('2', '2', '2');


#
# TABLE STRUCTURE FOR: v_rekap
#

DROP TABLE IF EXISTS `v_rekap`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_rekap` AS select `x`.`nomor_order` AS `nomor_order`,`x`.`tahun_order` AS `tahun_order`,`x`.`nomor_sample` AS `nomor_sample`,`x`.`tahun_sample` AS `tahun_sample`,`x`.`nama_perusahaan` AS `nama_perusahaan`,`x`.`nama_pemohon` AS `nama_pemohon`,`x`.`alamat_perusahaan` AS `alamat_perusahaan`,`x`.`telp_perusahaan` AS `telp_perusahaan`,`x`.`fax_perusahaan` AS `fax_perusahaan`,`x`.`created_date` AS `created_date`,`x`.`kode_uji` AS `kode_uji`,`x`.`unit` AS `unit`,`x`.`jumlah` AS `jumlah`,`x`.`nama_param` AS `nama_param`,`x`.`harga` AS `harga`,group_concat(`x`.`nama_param` separator ', ') AS `param`,sum(`x`.`harga`) AS `harga_total` from (select `b`.`nomor_order` AS `nomor_order`,`b`.`tahun_order` AS `tahun_order`,`a`.`nomor_sample` AS `nomor_sample`,`a`.`tahun_sample` AS `tahun_sample`,`d`.`nama_perusahaan` AS `nama_perusahaan`,`d`.`nama_pemohon` AS `nama_pemohon`,`d`.`alamat_perusahaan` AS `alamat_perusahaan`,`d`.`telp_perusahaan` AS `telp_perusahaan`,`d`.`fax_perusahaan` AS `fax_perusahaan`,`d`.`created_date` AS `created_date`,`a`.`kode_uji` AS `kode_uji`,`a`.`unit` AS `unit`,`a`.`jumlah` AS `jumlah`,`c`.`nama_param` AS `nama_param`,`c`.`harga` AS `harga` from (((`sipalab`.`tbl_sample` `a` left join `sipalab`.`tbl_sample_param` `b` on(`a`.`nomor_sample` = `b`.`nomor_sample` and `a`.`tahun_sample` = `b`.`tahun_sample` and `a`.`nomor_order` = `b`.`nomor_order` and `a`.`tahun_order` = `b`.`tahun_order`)) left join `sipalab`.`tbl_param` `c` on(`b`.`id_parameter` = `c`.`id_param`)) left join `sipalab`.`tbl_order` `d` on(`a`.`nomor_order` = `d`.`nomor_order` and `a`.`tahun_order` = `d`.`tahun_order`))) `x` group by `x`.`nomor_sample`,`x`.`tahun_sample`;

utf8mb4_general_ci;

INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('1', '2019', '1', '2019', NULL, NULL, NULL, NULL, NULL, NULL, 'KODE UJI 1', 'JERIGEN', '1000', 'Suhu', '9500', 'Suhu, TDS portable, TSS', '66000');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('1', '2020', '1', '2020', 'PT. TATA NUTRISNA', 'P. HIDAYAT', 'JL. LANBAU KM.6 DS. LEUWINUTUNG KEC. CITEUREUP KAB. BOGOR', '082299222900', '', '2020-11-30 20:50:35', 'INLET IPAL', 'BOTOL AMDK', '1500', 'TSS', '34000', 'TSS, BOD, COD', '159850');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('1', '2020', '2', '2020', 'PT. TATA NUTRISNA', 'P. HIDAYAT', 'JL. LANBAU KM.6 DS. LEUWINUTUNG KEC. CITEUREUP KAB. BOGOR', '082299222900', '', '2020-11-30 20:50:35', 'OUTLET IPAL', 'BOTOL AMDK', '1500', 'DHL', '15900', 'DHL, pH, COD, TSS', '147600');


#
# TABLE STRUCTURE FOR: v_sample
#

DROP TABLE IF EXISTS `v_sample`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_sample` AS select `x`.`nomor_order` AS `nomor_order`,`x`.`tahun_order` AS `tahun_order`,`x`.`nomor_sample` AS `nomor_sample`,`x`.`tahun_sample` AS `tahun_sample`,`x`.`kode_uji` AS `kode_uji`,`x`.`unit` AS `unit`,`x`.`jumlah` AS `jumlah`,`x`.`nama_param` AS `nama_param`,`x`.`harga` AS `harga`,group_concat(`x`.`nama_param` separator ', ') AS `param`,sum(`x`.`harga`) AS `harga_total` from (select `b`.`nomor_order` AS `nomor_order`,`b`.`tahun_order` AS `tahun_order`,`a`.`nomor_sample` AS `nomor_sample`,`a`.`tahun_sample` AS `tahun_sample`,`a`.`kode_uji` AS `kode_uji`,`a`.`unit` AS `unit`,`a`.`jumlah` AS `jumlah`,`c`.`nama_param` AS `nama_param`,`c`.`harga` AS `harga` from ((`sipalab`.`tbl_sample` `a` left join `sipalab`.`tbl_sample_param` `b` on(`a`.`nomor_sample` = `b`.`nomor_sample` and `a`.`tahun_sample` = `b`.`tahun_sample` and `a`.`nomor_order` = `b`.`nomor_order` and `a`.`tahun_order` = `b`.`tahun_order`)) left join `sipalab`.`tbl_param` `c` on(`b`.`id_parameter` = `c`.`id_param`))) `x` group by `x`.`nomor_sample`,`x`.`tahun_sample`;

utf8mb4_general_ci;

INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('1', '2019', '1', '2019', 'KODE UJI 1', 'JERIGEN', '1000', 'TSS', '34000', 'TSS, TDS portable, Suhu', '66000');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('1', '2020', '1', '2020', 'INLET IPAL', 'BOTOL AMDK', '1500', 'COD', '63850', 'COD, BOD, TSS', '159850');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('1', '2020', '2', '2020', 'OUTLET IPAL', 'BOTOL AMDK', '1500', 'pH', '33850', 'pH, DHL, TSS, COD', '147600');


