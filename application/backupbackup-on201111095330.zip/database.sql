#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  `username` varchar(100) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ci_sessions_timestamp` (`timestamp`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`, `username`) VALUES ('hi4ho2t004621qr1mdfmq2b9j5737dnr', '::1', '1605084809', '__ci_last_regenerate|i:1605081578;identity|s:13:\"ver@gmail.com\";username|s:12:\"adminsipalab\";email|s:13:\"ver@gmail.com\";user_id|s:4:\"1000\";old_last_login|s:10:\"1603766977\";sesusername|s:12:\"adminsipalab\";seslokasi|s:3:\"100\";acdel|b:0;', 'adminsipalab');


#
# TABLE STRUCTURE FOR: groups
#

DROP TABLE IF EXISTS `groups`;

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('1', 'admin', 'Administrator');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('10', 'DINAS_ALL', 'DINAS_ALL');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('11', 'DINAS_DAFDUK', 'DINAS_DAFDUK');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('12', 'DINAS_CAPIL', 'DINAS_CAPIL');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('13', 'DINAS_P4', 'DINAS_P4');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('14', 'DINAS_PINDAH_DATANG', 'DINAS_PINDAH_DATANG');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('20', 'UPT', 'UPT');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('30', 'KECAMATAN', 'KECAMATAN');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('100', 'VERIFIKATOR_ALL', 'VERIFIKATOR_ALL');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('111', 'VER_DAFDUK', 'VER_DAFDUK');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('112', 'VER_CAPIL', 'VER_CAPIL');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('113', 'VER_P4', 'VER_P4');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('114', 'VER_PINDAHDATANG', 'VER_PINDAHDATANG');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('120', 'VER_UPT', 'VER_UPT');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('130', 'VER_KEC', 'VER_KEC');


#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS `login_attempts`;

CREATE TABLE `login_attempts` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO `migrations` (`version`) VALUES ('1');


#
# TABLE STRUCTURE FOR: tbl_catatan
#

DROP TABLE IF EXISTS `tbl_catatan`;

CREATE TABLE `tbl_catatan` (
  `id_catatan` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_ambil_sample` datetime DEFAULT NULL,
  `transport` varchar(100) DEFAULT NULL,
  `pengawetan` varchar(100) DEFAULT NULL,
  `paramlap` varchar(100) DEFAULT NULL,
  `nomor_order` int(11) DEFAULT NULL,
  `tahun_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_catatan`),
  KEY `idx_catatan` (`nomor_order`,`tahun_order`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_catatan` (`id_catatan`, `tgl_ambil_sample`, `transport`, `pengawetan`, `paramlap`, `nomor_order`, `tahun_order`) VALUES ('1', NULL, '', '', '', '1', '2019');
INSERT INTO `tbl_catatan` (`id_catatan`, `tgl_ambil_sample`, `transport`, `pengawetan`, `paramlap`, `nomor_order`, `tahun_order`) VALUES ('2', NULL, 'MOBIL', '', '', '2', '2020');
INSERT INTO `tbl_catatan` (`id_catatan`, `tgl_ambil_sample`, `transport`, `pengawetan`, `paramlap`, `nomor_order`, `tahun_order`) VALUES ('3', '0000-00-00 00:00:00', '', '', '', '3', '2020');
INSERT INTO `tbl_catatan` (`id_catatan`, `tgl_ambil_sample`, `transport`, `pengawetan`, `paramlap`, `nomor_order`, `tahun_order`) VALUES ('4', NULL, '', '', '', '4', '2020');
INSERT INTO `tbl_catatan` (`id_catatan`, `tgl_ambil_sample`, `transport`, `pengawetan`, `paramlap`, `nomor_order`, `tahun_order`) VALUES ('6', NULL, '', '', '', '5', '2020');
INSERT INTO `tbl_catatan` (`id_catatan`, `tgl_ambil_sample`, `transport`, `pengawetan`, `paramlap`, `nomor_order`, `tahun_order`) VALUES ('7', NULL, 'PESAWAT SELAM', '', '', '6', '2020');
INSERT INTO `tbl_catatan` (`id_catatan`, `tgl_ambil_sample`, `transport`, `pengawetan`, `paramlap`, `nomor_order`, `tahun_order`) VALUES ('11', NULL, 'MOBIL', '', '', '7', '2020');
INSERT INTO `tbl_catatan` (`id_catatan`, `tgl_ambil_sample`, `transport`, `pengawetan`, `paramlap`, `nomor_order`, `tahun_order`) VALUES ('23', NULL, 'MOBIL', '', '', '8', '2020');
INSERT INTO `tbl_catatan` (`id_catatan`, `tgl_ambil_sample`, `transport`, `pengawetan`, `paramlap`, `nomor_order`, `tahun_order`) VALUES ('24', '2020-11-13 00:00:00', 'MOBIL', 'AS', '', '81', '2020');


#
# TABLE STRUCTURE FOR: tbl_config
#

DROP TABLE IF EXISTS `tbl_config`;

CREATE TABLE `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_config` varchar(255) DEFAULT NULL,
  `value_config` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_config` (`id`, `nama_config`, `value_config`) VALUES ('1', 'TGL ISO', '04 Desember 2019');
INSERT INTO `tbl_config` (`id`, `nama_config`, `value_config`) VALUES ('2', 'FORM ISO', 'FORM 7.5-02');
INSERT INTO `tbl_config` (`id`, `nama_config`, `value_config`) VALUES ('3', 'TERBITAN', 'Terbitan/Rev: 3/1');
INSERT INTO `tbl_config` (`id`, `nama_config`, `value_config`) VALUES ('4', 'BML', 'Permen LH NO. 5 Th. 2014');


#
# TABLE STRUCTURE FOR: tbl_order
#

DROP TABLE IF EXISTS `tbl_order`;

CREATE TABLE `tbl_order` (
  `id_order` int(11) NOT NULL AUTO_INCREMENT,
  `nomor_order` int(11) DEFAULT NULL,
  `tahun_order` int(11) DEFAULT NULL,
  `nama_pemohon` varchar(100) DEFAULT NULL,
  `nama_perusahaan` varchar(100) DEFAULT NULL,
  `alamat_perusahaan` varchar(255) DEFAULT NULL,
  `telp_perusahaan` varchar(100) DEFAULT NULL,
  `fax_perusahaan` varchar(100) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_order`),
  KEY `idx_order` (`nomor_order`,`tahun_order`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_order` (`id_order`, `nomor_order`, `tahun_order`, `nama_pemohon`, `nama_perusahaan`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`) VALUES ('1', '1', '2019', 'ADE MUCHLIS', 'PT. COBA COBA', 'CIBINONG, BOGOR', '0811111', '021111', '2020-10-22 21:59:49');
INSERT INTO `tbl_order` (`id_order`, `nomor_order`, `tahun_order`, `nama_pemohon`, `nama_perusahaan`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`) VALUES ('2', '2', '2020', 'CINTA', 'PT. COBA COBA1', 'CISARUA BOGOR', '0811111', '021111', '2020-10-22 22:05:51');
INSERT INTO `tbl_order` (`id_order`, `nomor_order`, `tahun_order`, `nama_pemohon`, `nama_perusahaan`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`) VALUES ('3', '3', '2020', 'ADE MUCHLISSS', 'PT. COBA ORDER 3', 'CIBINONG, BOGOR', '0811111', '021111', '2020-10-22 22:17:35');
INSERT INTO `tbl_order` (`id_order`, `nomor_order`, `tahun_order`, `nama_pemohon`, `nama_perusahaan`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`) VALUES ('4', '4', '2020', 'ADE MUCHLISSS', 'PT. COBA COBA 4', 'CIBINONG, BOGOR', '0811111', '021111', '2020-10-22 22:19:58');
INSERT INTO `tbl_order` (`id_order`, `nomor_order`, `tahun_order`, `nama_pemohon`, `nama_perusahaan`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`) VALUES ('6', '5', '2020', 'ADE MUCHLISSS', 'PT. COBA COBA5', 'CIBINONG, BOGOR', '0811111', '021111', '2020-10-22 22:29:15');
INSERT INTO `tbl_order` (`id_order`, `nomor_order`, `tahun_order`, `nama_pemohon`, `nama_perusahaan`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`) VALUES ('7', '6', '2020', 'ADE MUCHLISSS EDIT', 'PT. COBA COBA EDIT 6', 'CIBINONG, BOGOR EDIT', '0811111', '021111', '2020-10-22 22:32:44');
INSERT INTO `tbl_order` (`id_order`, `nomor_order`, `tahun_order`, `nama_pemohon`, `nama_perusahaan`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`) VALUES ('11', '7', '2020', 'PEMOHON ORDER 7', 'PT. 7', 'TUJUH BOGOR CIBINONG KARADENAN', '082299222900', '021231468', '2020-10-24 22:45:08');
INSERT INTO `tbl_order` (`id_order`, `nomor_order`, `tahun_order`, `nama_pemohon`, `nama_perusahaan`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`) VALUES ('21', '80', '2020', 'ADE MUCHLIS', 'PT. MAJU MUNDUR EDIT 1', 'CIBINONG, PAKANSARI', '082299222900', '02112345678', '2020-10-25 21:34:34');
INSERT INTO `tbl_order` (`id_order`, `nomor_order`, `tahun_order`, `nama_pemohon`, `nama_perusahaan`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`) VALUES ('22', '81', '2020', 'ADE MUCHLIS', 'PT. ABCD', 'CIBINONG', '082299222900', '0212345678', '2020-11-11 15:03:51');


#
# TABLE STRUCTURE FOR: tbl_param
#

DROP TABLE IF EXISTS `tbl_param`;

CREATE TABLE `tbl_param` (
  `id_param` int(11) NOT NULL AUTO_INCREMENT,
  `nama_param` varchar(255) NOT NULL,
  `tipe_param` varchar(255) NOT NULL,
  `harga` int(255) NOT NULL,
  PRIMARY KEY (`id_param`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('1', 'Suhu', 'Air dan Air Limbah', '9500');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('2', 'TDS portable', 'Air dan Air Limbah', '22500');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('3', 'TDS Gravimetri', 'Air dan Air Limbah', '34900');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('4', 'TSS', 'Air dan Air Limbah', '34000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('5', 'Residu Total Gravimetri', 'Air dan Air Limbah', '30400');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('6', 'Salinitas', 'Air dan Air Limbah', '14200');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('7', 'DHL', 'Air dan Air Limbah', '15900');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('8', 'Kekeruhan', 'Air dan Air Limbah', '15336');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('9', 'Warna', 'Air dan Air Limbah', '15700');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('10', 'pH', 'Air dan Air Limbah', '33850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('11', 'Sulfide', 'Air dan Air Limbah', '17350');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('12', 'Klorida (Cl) free', 'Air dan Air Limbah', '28300');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('13', 'Klorin (Cl2) total', 'Air dan Air Limbah', '28300');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('14', 'NH3-N', 'Air dan Air Limbah', '24400');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('15', 'NO3-N (HACH)', 'Air dan Air Limbah', '24650');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('16', 'NO3-N  (SNI)', 'Air dan Air Limbah', '23800');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('17', 'NO2-N  (HACH)', 'Air dan Air Limbah', '21250');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('18', 'NO2-N (SNI)', 'Air dan Air Limbah', '24350');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('19', 'Ortho Posphat', 'Air dan Air Limbah', '23050');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('20', 'Total Fosfat (P-total)', 'Air dan Air Limbah', '26800');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('21', 'DO', 'Air dan Air Limbah', '20100');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('22', 'DO Titrimetri', 'Air dan Air Limbah', '32800');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('23', 'Barium (HACH)', 'Air dan Air Limbah', '38000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('24', 'Barium secara AAS', 'Air dan Air Limbah', '33100');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('25', 'Crom Heksa (HACH)', 'Air dan Air Limbah', '33500');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('26', 'Crom Heksa (SNI)', 'Air dan Air Limbah', '27250');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('27', 'Cyanide(HACH)', 'Air dan Air Limbah', '52300');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('28', 'Crom Total secara AAS', 'Air dan Air Limbah', '30900');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('29', 'Sulfat (HACH)', 'Air dan Air Limbah', '24150');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('30', 'Sulfat (SNI)', 'Air dan Air Limbah', '24250');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('31', 'Mn ', 'Air dan Air Limbah', '31850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('32', 'Fe', 'Air dan Air Limbah', '32000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('33', 'Zn ', 'Air dan Air Limbah', '31850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('34', 'Cu ', 'Air dan Air Limbah', '31850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('35', 'BOD', 'Air dan Air Limbah', '62000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('36', 'COD', 'Air dan Air Limbah', '63850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('37', 'Cd ', 'Air dan Air Limbah', '31850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('38', 'Pb', 'Air dan Air Limbah', '31850');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('39', 'Hg ', 'Air dan Air Limbah', '79950');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('40', 'Fluoride (HACH)', 'Air dan Air Limbah', '29250');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('41', 'Phenol (HACH)', 'Air dan Air Limbah', '53650');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('42', 'Minyak dan Lemak', 'Air dan Air Limbah', '42650');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('43', 'Detergen (HACH)', 'Air dan Air Limbah', '52050');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('44', 'Arsen ', 'Air dan Air Limbah', '66300');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('45', 'Coli dan Total Coliform', 'Air dan Air Limbah', '181050');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('46', 'Alkalinitas', 'Air dan Air Limbah', '14500');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('47', 'Aciditas', 'Air dan Air Limbah', '14500');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('48', 'Kesadahan Ca', 'Air dan Air Limbah', '20000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('49', 'Kesadahan Mg', 'Air dan Air Limbah', '20000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('50', 'Kesadahan Total', 'Air dan Air Limbah', '20000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('51', 'Nilai Permanganat ', 'Air dan Air Limbah', '21500');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('52', 'Nitrogen Organik', 'Air dan Air Limbah', '38800');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('53', 'Ortho Posphat', 'Air dan Air Limbah', '23050');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('54', 'Total Fosfat (P-total)', 'Air dan Air Limbah', '26800');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('55', 'Selenium ', 'Air dan Air Limbah', '66350');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('56', 'Suhu Udara', 'Udara Ambient', '24100');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('57', 'Kelembaban udara dan CO2', 'Udara Ambient', '37650');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('58', 'Partikel debu (TSP) 1 jam', 'Udara Ambient', '102100');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('59', 'Sulfurdioksida ( SO2 )', 'Udara Ambient', '103800');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('60', 'Nitrogen Oksida ( NO2 )', 'Udara Ambient', '62000');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('61', 'Dihidrogen Sulfur ( H2S )', 'Udara Ambient', '91050');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('62', 'Amonia (NH3)', 'Udara Ambient', '102600');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('63', 'Ozon ( O3 )', 'Udara Ambient', '101350');
INSERT INTO `tbl_param` (`id_param`, `nama_param`, `tipe_param`, `harga`) VALUES ('64', 'Kebisingan', 'Udara Ambient', '37650');


#
# TABLE STRUCTURE FOR: tbl_sample
#

DROP TABLE IF EXISTS `tbl_sample`;

CREATE TABLE `tbl_sample` (
  `id_sample` int(11) NOT NULL AUTO_INCREMENT,
  `nomor_sample` int(11) DEFAULT NULL,
  `tahun_sample` int(11) DEFAULT NULL,
  `kode_uji` varchar(100) DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `jumlah` varchar(100) DEFAULT NULL,
  `nomor_order` int(11) DEFAULT NULL,
  `tahun_order` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_sample`),
  KEY `idx_sample` (`nomor_order`,`tahun_order`,`nomor_sample`,`tahun_sample`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('1', '1', '2019', 'KODE UJI 1', 'JERIGEN', '1000', '1', '2019', '2020-10-22 22:00:29');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('3', '3', '2020', 'KODE 2 UJI 1', 'KANTONG PLASTIK', '2', '2', '2020', '2020-10-22 22:06:29');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('4', '4', '2020', 'KODE UJI ORDER 3 SAMPLE 4', 'JERIGEN', '1000', '3', '2020', '2020-10-22 22:18:08');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('5', '5', '2020', 'KODE UJI 5', 'JERIGEN', '1000', '4', '2020', '2020-10-22 22:20:19');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('6', '6', '2020', 'KODE UJI 6', 'JERIGEN', 'SAD', '5', '2020', '2020-10-22 22:30:19');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('7', '7', '2020', 'KODE UJI 7', 'JERIGEN', '1000', '5', '2020', '2020-10-22 22:30:42');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('8', '8', '2020', 'KODE UJI 8', 'JERIGEN', '100', '6', '2020', '2020-10-22 22:33:25');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('11', '9', '2020', 'KODE UJI ANOMALI', 'KEMASAN ANOMALI', '1000', '5', '2020', '2020-10-24 17:52:08');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('12', '10', '2020', 'KODE UJI ANOMALI1', 'JERIGEN1', '1000', '6', '2020', '2020-10-24 18:02:05');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('13', '11', '2020', 'ASD', 'DASD', 'ASD', '6', '2020', '2020-10-24 18:14:57');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('19', '12', '2020', 'KODE UJI A', 'KANTONG', '20', '7', '2020', '2020-10-24 22:45:35');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('20', '13', '2020', 'KODE UJI 2', 'ADE', '8989', '7', '2020', '2020-10-24 22:46:15');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('30', '14', '2020', 'KODE UJI 1', 'JERIGEN', '1000', '8', '2020', '2020-10-25 21:35:07');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('31', '100', '2020', 'KODE UJI 2', 'PLASTIK', '10', '8', '2020', '2020-10-25 21:36:02');
INSERT INTO `tbl_sample` (`id_sample`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nomor_order`, `tahun_order`, `created_date`) VALUES ('32', '101', '2020', 'KODE UJI SAMPLE 101', 'PLASTIK', '10', '81', '2020', '2020-11-11 15:04:38');


#
# TABLE STRUCTURE FOR: tbl_sample_param
#

DROP TABLE IF EXISTS `tbl_sample_param`;

CREATE TABLE `tbl_sample_param` (
  `id_sample_param` int(11) NOT NULL AUTO_INCREMENT,
  `id_parameter` int(11) NOT NULL,
  `nomor_sample` int(11) NOT NULL,
  `tahun_sample` int(11) NOT NULL,
  `nomor_order` int(11) NOT NULL,
  `tahun_order` int(11) NOT NULL,
  PRIMARY KEY (`id_sample_param`),
  KEY `idx_sample_param` (`nomor_order`,`tahun_order`,`nomor_sample`,`tahun_sample`)
) ENGINE=InnoDB AUTO_INCREMENT=283 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('1', '1', '1', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('2', '2', '1', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('3', '4', '1', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('4', '5', '1', '2020', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('5', '7', '1', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('6', '8', '1', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('7', '10', '1', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('8', '11', '1', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('9', '13', '1', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('10', '16', '1', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('11', '50', '2', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('12', '53', '2', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('13', '56', '2', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('14', '59', '2', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('15', '62', '2', '2019', '1', '2019');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('16', '26', '3', '2020', '2', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('17', '29', '3', '2020', '2', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('18', '32', '3', '2020', '2', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('19', '35', '3', '2020', '2', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('20', '38', '3', '2020', '2', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('21', '1', '4', '2020', '3', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('22', '2', '4', '2020', '3', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('23', '3', '4', '2020', '3', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('24', '4', '4', '2020', '3', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('25', '5', '4', '2020', '3', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('26', '6', '4', '2020', '3', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('27', '1', '5', '2020', '4', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('28', '2', '5', '2020', '4', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('29', '3', '5', '2020', '4', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('30', '4', '5', '2020', '4', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('31', '5', '5', '2020', '4', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('32', '6', '5', '2020', '4', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('33', '7', '5', '2020', '4', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('34', '1', '6', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('35', '4', '6', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('36', '5', '6', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('37', '44', '6', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('38', '47', '6', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('39', '50', '6', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('40', '53', '6', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('41', '56', '6', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('42', '59', '6', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('43', '62', '6', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('44', '1', '7', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('45', '2', '7', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('46', '3', '7', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('47', '4', '7', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('48', '5', '7', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('49', '6', '7', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('50', '7', '7', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('51', '8', '7', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('52', '9', '7', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('53', '1', '8', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('54', '2', '8', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('55', '3', '8', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('56', '4', '8', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('57', '5', '8', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('58', '9', '8', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('59', '10', '8', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('60', '11', '8', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('61', '12', '8', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('62', '13', '8', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('86', '1', '9', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('87', '2', '9', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('88', '3', '9', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('89', '4', '9', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('90', '5', '9', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('91', '6', '9', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('92', '7', '9', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('93', '8', '9', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('94', '9', '9', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('95', '10', '9', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('96', '11', '9', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('97', '12', '9', '2020', '5', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('98', '1', '10', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('99', '4', '10', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('100', '7', '10', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('101', '10', '10', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('102', '13', '10', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('103', '16', '10', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('104', '19', '10', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('105', '1', '11', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('106', '2', '11', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('107', '4', '11', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('108', '5', '11', '2020', '6', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('142', '1', '12', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('143', '4', '12', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('144', '7', '12', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('145', '10', '12', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('146', '13', '12', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('147', '16', '12', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('148', '17', '12', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('149', '56', '13', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('150', '57', '13', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('151', '58', '13', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('152', '59', '13', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('153', '60', '13', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('154', '61', '13', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('155', '62', '13', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('156', '63', '13', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('157', '64', '13', '2020', '7', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('263', '2', '15', '2020', '8', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('264', '5', '15', '2020', '8', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('265', '8', '15', '2020', '8', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('266', '11', '15', '2020', '8', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('267', '14', '15', '2020', '8', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('268', '17', '15', '2020', '8', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('269', '1', '14', '2020', '8', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('270', '4', '14', '2020', '8', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('271', '7', '14', '2020', '8', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('272', '10', '14', '2020', '8', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('273', '13', '14', '2020', '8', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('274', '1', '101', '2020', '81', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('275', '2', '101', '2020', '81', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('276', '4', '101', '2020', '81', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('277', '5', '101', '2020', '81', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('278', '8', '101', '2020', '81', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('279', '11', '101', '2020', '81', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('280', '13', '101', '2020', '81', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('281', '16', '101', '2020', '81', '2020');
INSERT INTO `tbl_sample_param` (`id_sample_param`, `id_parameter`, `nomor_sample`, `tahun_sample`, `nomor_order`, `tahun_order`) VALUES ('282', '19', '101', '2020', '81', '2020');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(80) NOT NULL,
  `salt` varchar(40) NOT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `wilayah` varchar(20) DEFAULT NULL,
  `id_wilayah` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `wilayah`, `id_wilayah`) VALUES ('1', '2130706433', 'admin', '$2y$08$5KtHSlyQiwloT.0EZakC6.5IlcJXa7q9PXYy7VCl3LlU0SZUtTVIq', '', 'ades.muchlis@gmail.com', '', NULL, NULL, NULL, '1268889823', '1587957075', '1', 'ade', 'muchlis', 'ADMIN', '0', NULL, NULL);
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `wilayah`, `id_wilayah`) VALUES ('1000', '::1', 'adminsipalab', '$2y$08$geZEwpqBeNSIBbuYNFoHLuflONM/qpOxhcwD1jXqfNNmV7t4KmxIG', '', 'ver@gmail.com', NULL, NULL, NULL, NULL, '1584069727', '1605081587', '1', 'verificator', 'verificator', 'VERIFICATOR', '0', 'VERIFICATOR', NULL);


#
# TABLE STRUCTURE FOR: users_groups
#

DROP TABLE IF EXISTS `users_groups`;

CREATE TABLE `users_groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('1', '1', '1');
INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('2', '1000', '100');


#
# TABLE STRUCTURE FOR: v_rekap
#

DROP TABLE IF EXISTS `v_rekap`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_rekap` AS select `x`.`nomor_order` AS `nomor_order`,`x`.`tahun_order` AS `tahun_order`,`x`.`nomor_sample` AS `nomor_sample`,`x`.`tahun_sample` AS `tahun_sample`,`x`.`nama_perusahaan` AS `nama_perusahaan`,`x`.`nama_pemohon` AS `nama_pemohon`,`x`.`alamat_perusahaan` AS `alamat_perusahaan`,`x`.`telp_perusahaan` AS `telp_perusahaan`,`x`.`fax_perusahaan` AS `fax_perusahaan`,`x`.`created_date` AS `created_date`,`x`.`kode_uji` AS `kode_uji`,`x`.`unit` AS `unit`,`x`.`jumlah` AS `jumlah`,`x`.`nama_param` AS `nama_param`,`x`.`harga` AS `harga`,group_concat(`x`.`nama_param` separator ', ') AS `param`,sum(`x`.`harga`) AS `harga_total` from (select `b`.`nomor_order` AS `nomor_order`,`b`.`tahun_order` AS `tahun_order`,`a`.`nomor_sample` AS `nomor_sample`,`a`.`tahun_sample` AS `tahun_sample`,`d`.`nama_perusahaan` AS `nama_perusahaan`,`d`.`nama_pemohon` AS `nama_pemohon`,`d`.`alamat_perusahaan` AS `alamat_perusahaan`,`d`.`telp_perusahaan` AS `telp_perusahaan`,`d`.`fax_perusahaan` AS `fax_perusahaan`,`d`.`created_date` AS `created_date`,`a`.`kode_uji` AS `kode_uji`,`a`.`unit` AS `unit`,`a`.`jumlah` AS `jumlah`,`c`.`nama_param` AS `nama_param`,`c`.`harga` AS `harga` from (((`sipalab`.`tbl_sample` `a` left join `sipalab`.`tbl_sample_param` `b` on(`a`.`nomor_sample` = `b`.`nomor_sample` and `a`.`tahun_sample` = `b`.`tahun_sample` and `a`.`nomor_order` = `b`.`nomor_order` and `a`.`tahun_order` = `b`.`tahun_order`)) left join `sipalab`.`tbl_param` `c` on(`b`.`id_parameter` = `c`.`id_param`)) left join `sipalab`.`tbl_order` `d` on(`a`.`nomor_order` = `d`.`nomor_order` and `a`.`tahun_order` = `d`.`tahun_order`))) `x` group by `x`.`nomor_sample`,`x`.`tahun_sample`;

utf8mb4_general_ci;

INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('1', '2019', '1', '2019', 'PT. COBA COBA', 'ADE MUCHLIS', 'CIBINONG, BOGOR', '0811111', '021111', '2020-10-22 21:59:49', 'KODE UJI 1', 'JERIGEN', '1000', 'Suhu', '9500', 'Suhu, TDS portable, TSS, DHL, Kekeruhan, pH, Sulfide, Klorin (Cl2) total, NO3-N  (SNI)', '200536');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('2', '2020', '3', '2020', 'PT. COBA COBA1', 'CINTA', 'CISARUA BOGOR', '0811111', '021111', '2020-10-22 22:05:51', 'KODE 2 UJI 1', 'KANTONG PLASTIK', '2', 'Crom Heksa (SNI)', '27250', 'Crom Heksa (SNI), Sulfat (HACH), Fe, BOD, Pb', '177250');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('3', '2020', '4', '2020', 'PT. COBA ORDER 3', 'ADE MUCHLISSS', 'CIBINONG, BOGOR', '0811111', '021111', '2020-10-22 22:17:35', 'KODE UJI ORDER 3 SAMPLE 4', 'JERIGEN', '1000', 'Suhu', '9500', 'Suhu, TDS portable, TDS Gravimetri, TSS, Residu Total Gravimetri, Salinitas', '145500');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('4', '2020', '5', '2020', 'PT. COBA COBA 4', 'ADE MUCHLISSS', 'CIBINONG, BOGOR', '0811111', '021111', '2020-10-22 22:19:58', 'KODE UJI 5', 'JERIGEN', '1000', 'Suhu', '9500', 'Suhu, TDS portable, TDS Gravimetri, TSS, Residu Total Gravimetri, Salinitas, DHL', '161400');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('5', '2020', '6', '2020', 'PT. COBA COBA5', 'ADE MUCHLISSS', 'CIBINONG, BOGOR', '0811111', '021111', '2020-10-22 22:29:15', 'KODE UJI 6', 'JERIGEN', 'SAD', 'Suhu', '9500', 'Suhu, TSS, Residu Total Gravimetri, Arsen , Aciditas, Kesadahan Total, Ortho Posphat, Suhu Udara, Sulfurdioksida ( SO2 ), Amonia (NH3)', '428250');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('5', '2020', '7', '2020', 'PT. COBA COBA5', 'ADE MUCHLISSS', 'CIBINONG, BOGOR', '0811111', '021111', '2020-10-22 22:29:15', 'KODE UJI 7', 'JERIGEN', '1000', 'Suhu', '9500', 'Suhu, TDS portable, TDS Gravimetri, TSS, Residu Total Gravimetri, Salinitas, DHL, Kekeruhan, Warna', '192436');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('6', '2020', '8', '2020', 'PT. COBA COBA EDIT 6', 'ADE MUCHLISSS EDIT', 'CIBINONG, BOGOR EDIT', '0811111', '021111', '2020-10-22 22:32:44', 'KODE UJI 8', 'JERIGEN', '100', 'Suhu', '9500', 'Suhu, TDS portable, TDS Gravimetri, TSS, Residu Total Gravimetri, Warna, pH, Sulfide, Klorida (Cl) free, Klorin (Cl2) total', '254800');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('5', '2020', '9', '2020', 'PT. COBA COBA5', 'ADE MUCHLISSS', 'CIBINONG, BOGOR', '0811111', '021111', '2020-10-22 22:29:15', 'KODE UJI ANOMALI', 'KEMASAN ANOMALI', '1000', 'Suhu', '9500', 'Suhu, TDS portable, TDS Gravimetri, TSS, Residu Total Gravimetri, Salinitas, DHL, Kekeruhan, Warna, pH, Sulfide, Klorida (Cl) free', '271936');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('6', '2020', '10', '2020', 'PT. COBA COBA EDIT 6', 'ADE MUCHLISSS EDIT', 'CIBINONG, BOGOR EDIT', '0811111', '021111', '2020-10-22 22:32:44', 'KODE UJI ANOMALI1', 'JERIGEN1', '1000', 'Suhu', '9500', 'Suhu, TSS, DHL, pH, Klorin (Cl2) total, NO3-N  (SNI), Ortho Posphat', '168400');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('6', '2020', '11', '2020', 'PT. COBA COBA EDIT 6', 'ADE MUCHLISSS EDIT', 'CIBINONG, BOGOR EDIT', '0811111', '021111', '2020-10-22 22:32:44', 'ASD', 'DASD', 'ASD', 'Suhu', '9500', 'Suhu, TDS portable, TSS, Residu Total Gravimetri', '96400');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('7', '2020', '12', '2020', 'PT. 7', 'PEMOHON ORDER 7', 'TUJUH BOGOR CIBINONG KARADENAN', '082299222900', '021231468', '2020-10-24 22:45:08', 'KODE UJI A', 'KANTONG', '20', 'Suhu', '9500', 'Suhu, TSS, DHL, pH, Klorin (Cl2) total, NO3-N  (SNI), NO2-N  (HACH)', '166600');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('7', '2020', '13', '2020', 'PT. 7', 'PEMOHON ORDER 7', 'TUJUH BOGOR CIBINONG KARADENAN', '082299222900', '021231468', '2020-10-24 22:45:08', 'KODE UJI 2', 'ADE', '8989', 'Suhu Udara', '24100', 'Suhu Udara, Kelembaban udara dan CO2, Partikel debu (TSP) 1 jam, Sulfurdioksida ( SO2 ), Nitrogen Oksida ( NO2 ), Dihidrogen Sulfur ( H2S ), Amonia (NH3), Ozon ( O3 ), Kebisingan', '662300');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('8', '2020', '14', '2020', NULL, NULL, NULL, NULL, NULL, NULL, 'KODE UJI 1', 'JERIGEN', '1000', 'Suhu', '9500', 'Suhu, TSS, DHL, pH, Klorin (Cl2) total', '121550');
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES (NULL, NULL, '100', '2020', NULL, NULL, NULL, NULL, NULL, NULL, 'KODE UJI 2', 'PLASTIK', '10', NULL, NULL, NULL, NULL);
INSERT INTO `v_rekap` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `nama_perusahaan`, `nama_pemohon`, `alamat_perusahaan`, `telp_perusahaan`, `fax_perusahaan`, `created_date`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('81', '2020', '101', '2020', 'PT. ABCD', 'ADE MUCHLIS', 'CIBINONG', '082299222900', '0212345678', '2020-11-11 15:03:51', 'KODE UJI SAMPLE 101', 'PLASTIK', '10', 'Suhu', '9500', 'Suhu, TDS portable, TSS, Residu Total Gravimetri, Kekeruhan, Sulfide, Klorin (Cl2) total, NO3-N  (SNI), Ortho Posphat', '204236');


#
# TABLE STRUCTURE FOR: v_sample
#

DROP TABLE IF EXISTS `v_sample`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_sample` AS select `x`.`nomor_order` AS `nomor_order`,`x`.`tahun_order` AS `tahun_order`,`x`.`nomor_sample` AS `nomor_sample`,`x`.`tahun_sample` AS `tahun_sample`,`x`.`kode_uji` AS `kode_uji`,`x`.`unit` AS `unit`,`x`.`jumlah` AS `jumlah`,`x`.`nama_param` AS `nama_param`,`x`.`harga` AS `harga`,group_concat(`x`.`nama_param` separator ', ') AS `param`,sum(`x`.`harga`) AS `harga_total` from (select `b`.`nomor_order` AS `nomor_order`,`b`.`tahun_order` AS `tahun_order`,`a`.`nomor_sample` AS `nomor_sample`,`a`.`tahun_sample` AS `tahun_sample`,`a`.`kode_uji` AS `kode_uji`,`a`.`unit` AS `unit`,`a`.`jumlah` AS `jumlah`,`c`.`nama_param` AS `nama_param`,`c`.`harga` AS `harga` from ((`sipalab`.`tbl_sample` `a` left join `sipalab`.`tbl_sample_param` `b` on(`a`.`nomor_sample` = `b`.`nomor_sample` and `a`.`tahun_sample` = `b`.`tahun_sample` and `a`.`nomor_order` = `b`.`nomor_order` and `a`.`tahun_order` = `b`.`tahun_order`)) left join `sipalab`.`tbl_param` `c` on(`b`.`id_parameter` = `c`.`id_param`))) `x` group by `x`.`nomor_sample`,`x`.`tahun_sample`;

utf8mb4_general_ci;

INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('1', '2019', '1', '2019', 'KODE UJI 1', 'JERIGEN', '1000', 'Suhu', '9500', 'Suhu, TDS portable, TSS, DHL, Kekeruhan, pH, Sulfide, Klorin (Cl2) total, NO3-N  (SNI)', '200536');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('2', '2020', '3', '2020', 'KODE 2 UJI 1', 'KANTONG PLASTIK', '2', 'Crom Heksa (SNI)', '27250', 'Crom Heksa (SNI), Sulfat (HACH), Fe, BOD, Pb', '177250');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('3', '2020', '4', '2020', 'KODE UJI ORDER 3 SAMPLE 4', 'JERIGEN', '1000', 'Suhu', '9500', 'Suhu, TDS portable, TDS Gravimetri, TSS, Residu Total Gravimetri, Salinitas', '145500');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('4', '2020', '5', '2020', 'KODE UJI 5', 'JERIGEN', '1000', 'Suhu', '9500', 'Suhu, TDS portable, TDS Gravimetri, TSS, Residu Total Gravimetri, Salinitas, DHL', '161400');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('5', '2020', '6', '2020', 'KODE UJI 6', 'JERIGEN', 'SAD', 'Suhu', '9500', 'Suhu, TSS, Residu Total Gravimetri, Arsen , Aciditas, Kesadahan Total, Ortho Posphat, Suhu Udara, Sulfurdioksida ( SO2 ), Amonia (NH3)', '428250');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('5', '2020', '7', '2020', 'KODE UJI 7', 'JERIGEN', '1000', 'Suhu', '9500', 'Suhu, TDS portable, TDS Gravimetri, TSS, Residu Total Gravimetri, Salinitas, DHL, Kekeruhan, Warna', '192436');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('6', '2020', '8', '2020', 'KODE UJI 8', 'JERIGEN', '100', 'Suhu', '9500', 'Suhu, TDS portable, TDS Gravimetri, TSS, Residu Total Gravimetri, Warna, pH, Sulfide, Klorida (Cl) free, Klorin (Cl2) total', '254800');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('5', '2020', '9', '2020', 'KODE UJI ANOMALI', 'KEMASAN ANOMALI', '1000', 'Suhu', '9500', 'Suhu, TDS portable, TDS Gravimetri, TSS, Residu Total Gravimetri, Salinitas, DHL, Kekeruhan, Warna, pH, Sulfide, Klorida (Cl) free', '271936');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('6', '2020', '10', '2020', 'KODE UJI ANOMALI1', 'JERIGEN1', '1000', 'Suhu', '9500', 'Suhu, TSS, DHL, pH, Klorin (Cl2) total, NO3-N  (SNI), Ortho Posphat', '168400');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('6', '2020', '11', '2020', 'ASD', 'DASD', 'ASD', 'Suhu', '9500', 'Suhu, TDS portable, TSS, Residu Total Gravimetri', '96400');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('7', '2020', '12', '2020', 'KODE UJI A', 'KANTONG', '20', 'Suhu', '9500', 'Suhu, TSS, DHL, pH, Klorin (Cl2) total, NO3-N  (SNI), NO2-N  (HACH)', '166600');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('7', '2020', '13', '2020', 'KODE UJI 2', 'ADE', '8989', 'Suhu Udara', '24100', 'Suhu Udara, Kelembaban udara dan CO2, Partikel debu (TSP) 1 jam, Sulfurdioksida ( SO2 ), Nitrogen Oksida ( NO2 ), Dihidrogen Sulfur ( H2S ), Amonia (NH3), Ozon ( O3 ), Kebisingan', '662300');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('8', '2020', '14', '2020', 'KODE UJI 1', 'JERIGEN', '1000', 'Suhu', '9500', 'Suhu, TSS, DHL, pH, Klorin (Cl2) total', '121550');
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES (NULL, NULL, '100', '2020', 'KODE UJI 2', 'PLASTIK', '10', NULL, NULL, NULL, NULL);
INSERT INTO `v_sample` (`nomor_order`, `tahun_order`, `nomor_sample`, `tahun_sample`, `kode_uji`, `unit`, `jumlah`, `nama_param`, `harga`, `param`, `harga_total`) VALUES ('81', '2020', '101', '2020', 'KODE UJI SAMPLE 101', 'PLASTIK', '10', 'Suhu', '9500', 'Suhu, TDS portable, TSS, Residu Total Gravimetri, Kekeruhan, Sulfide, Klorin (Cl2) total, NO3-N  (SNI), Ortho Posphat', '204236');


